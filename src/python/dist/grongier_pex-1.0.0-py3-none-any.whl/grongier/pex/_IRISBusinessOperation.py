class _IRISBusinessOperation:
    """ Class for proxy objects that represent business operation instances in IRIS"""

    def __init__(self):
        self.irisHandle = None