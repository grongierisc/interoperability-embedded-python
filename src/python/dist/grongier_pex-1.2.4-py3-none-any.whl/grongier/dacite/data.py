from typing import Any, Mapping

Data = Mapping[str, Any]
